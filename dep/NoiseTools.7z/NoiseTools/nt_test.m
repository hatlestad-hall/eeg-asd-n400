p=mfilename('fullpath');
d=fileparts(p);


ls ([d,'/TEST'])