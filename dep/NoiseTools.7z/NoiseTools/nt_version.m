function y=nt_version, y='18-Feb-2020';
if nargout==0; disp(['version ', y]); disp('check for latest version at http//audition.ens.fr/adc/NoiseTools/'); clear y; end;
